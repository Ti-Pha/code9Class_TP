#enonse 1
alphabet="a,b,c,d,e,f,g"
in_upper=alphabet.upper()
print(in_upper)

#enonse 2
who_am_i="I'm Phawens LOUIS-JEAN"
when_split=who_am_i.split()
print(when_split)

#enonse 3
what_am_gonna_do="i capitalize all the first letter in this text"
when_capitalize=' ' .join(word.capitalize() for word in what_am_gonna_do.split())
print(when_capitalize)

#enonse 4
my_text = "just add value anywhere"
my_fav_programming_language = ''.join(word[0] for word in my_text.split() if word.isalpha())
output_capitalize=my_fav_programming_language.capitalize()
print(f"my favorite programming language is {output_capitalize}")

#enonse 5
advice="you have to have a laptop to take part to this challenge"
replace_all_a=advice.replace("a","@")
print(replace_all_a)

#enonse 6
my_text="I gonna print a text that you can not read"
let_try='' .join(reversed(my_text)).upper()
print(let_try)
#print(my_text[::-1].upper())

#enonse 7
the_text = "This is a program to find the index of the first a."

find_index = the_text.find('a')
print("The index of the first 'a' is :", find_index)



#enonse 8
example="Another example with lowercase for a chAracters"
find_indexes_a= [i for i in range(len(example)) if example[i] == 'a' or example[i]=='A']
print(find_indexes_a)

#enonse 9
text_example = "An example with lowercase a characters"
find_a_indexes = [i for i in range(len(text_example)) if text_example[i] == 'a']
print(find_a_indexes)

#enonse 10
chain="I am a text with no space"
chaine_without_space=chain.replace(" ", "")
longer_chain=len(chaine_without_space)
result = chaine_without_space + str(longer_chain)
print(result)

